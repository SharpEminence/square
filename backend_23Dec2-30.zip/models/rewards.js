var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var rewardsSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User" },
    rewardCategory: { type: Schema.Types.ObjectId, ref: "Rewards" },
    rewardPoints: { type: Number, default: 0 },
    rewardFor: { type: Schema.Types.ObjectId },
    isDeleted: { type: Boolean, default: false },
    created_at: Date,
    updated_at: Date,
  },
  { collection: "rewards" }
);

var Rewards = mongoose.model("Rewards", rewardsSchema);

module.exports = Rewards;
