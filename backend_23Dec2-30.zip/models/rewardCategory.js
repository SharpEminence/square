var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var rewardsCategorySchema = new Schema(
  {
    name: { type: String, default: null },
    title: { type: String, default: "" },
    rewardPoints: { type: Number, default: 0 },
    isDeleted: { type: Boolean, default: false },
    created_at: Date,
    updated_at: Date,
  },
  { collection: "rewardsCategory" }
);

var RewardsCategory = mongoose.model("RewardsCategory", rewardsCategorySchema);

module.exports = RewardsCategory;
