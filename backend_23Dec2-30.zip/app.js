require("dotenv").config();

var createError = require("http-errors");
var express = require("express");
var expressLayouts = require("express-ejs-layouts");

var cors = require("cors");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
var session = require("express-session");
var bodyParser = require("body-parser");
var flash = require("req-flash");
var oldInput = require("old-input");

var port = process.env.PORT || 3600;
const jwt = require("jsonwebtoken");

var User = require("./models/User");
var Agenda = require("./models/Agenda");
var AgendaJoin = require("./models/AgendaJoin");
var LiveQuestions = require("./models/LiveQuestion");

// var indexRouter = require('./routes/index');
// var usersRouter = require('./routes/users');

var app = express();

app.use(
  session({
    secret: "secret",
    resave: true,
    saveUninitialized: true,
  })
);
app.use(flash());
app.use(oldInput);

// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(cors());
app.use(expressLayouts);
app.use(logger("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.use(function (req, res, next) {
  res.locals.user = req.session.user_data;
  res.locals.active = req.session.active;
  next();
});
// app.use('/', indexRouter);
// app.use('/users', usersRouter);
require("./config/database");

require("./routes/router")(app);

app.get('/api/liveQuestion',async (req,res)=>{
try {
  console.log("live question req.query===============",req.query)
  let questionData = await LiveQuestions.find({agenda:req.query.agendaId}).populate('userData')
  res.send({
    status:200,
    message:"data fetched",
    data:questionData
  })
} catch (error) {
  console.log("error.message=========>",error.message)
  res.send({
    status:400,
    message:error.message,
    data:questionData
  })
}
})
// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});

let server = app.listen(port, () => {
  console.log("Port : 3600");
});
app.set("layout", "layouts/layout");

var io = require("socket.io")(server, {
  serveClient: false,
  // below are engine.IO options
  origins: "*:*",
  transports: ["polling"],
  pingInterval: 10000,
  pingTimeout: 5000,
  cookie: false,
});

io.use(function (socket, next) {
  if (socket.handshake.query && socket.handshake.query.token) {
    console.log("token--------", socket.handshake.query.token.split(" ")[1]);

    jwt.verify(
      socket.handshake.query.token.split(" ")[1],
      "vnrvjrekrke",
      function (err, decoded) {
        if (err) {
          console.log("error-------1-", err);
          return next(new Error("Authentication error"));
        }
        socket.decoded = decoded;
      }
    );
    next();
  } else {
    next(new Error("Authentication error"));
  }
}).on("connection", async (socket) => {
  console.log("a user connected------------------------------>", socket.id);

  const updateSocketId = await User.findOneAndUpdate(
    { token: socket.handshake.query.token.split(" ")[1] },
    { socketId: socket.id },
    { new: true }
  );
  console.log("updateSocketId============>", updateSocketId);

  socket.on("askQuestion", async (data, cb) => {
    console.log("askQuestion=========> ", data);
    const agendaDeatils = await Agenda.findOne({ _id: data.agendaId }).populate(
      "speakers"
    );
    console.log("agendaDeatils===============>", agendaDeatils);

    if (!agendaDeatils) {
      return new Error("Inavlid agendaId");
    }

    let attendeesData = await AgendaJoin.find({
      agenda: data.agendaId,
    }).populate("user");
    console.log("attendeesData============", attendeesData);

    if (attendeesData) {
      for (let attendee of attendeesData) {
        if (attendee.user.socketId) {
          console.log("updateSocketId", updateSocketId);
          console.log(
            "attendee.socketId=================",
            attendee.user.first_name,
            attendee.user.socketId
          );
          socket
            .to(attendee.user.socketId)
            // .broadcasts
            .emit("newMessage", {
              userData: updateSocketId,
              message: data.message,
            });
        }
      }

      try {
        const saveQuestion = new LiveQuestions({
          agenda: data.agendaId,
          userData: updateSocketId._id,
          message: data.message,
        });
        saveQuestion.save();
        
      } catch (error) {
        console.log("error saving question=========",error.message)
      }
    }
  });
});

module.exports = app;
