var User = require("./../../../../models/User");
var RewardsCategory = require("./../../../../models/rewardCategory");
var Rewards = require("./../../../../models/rewards");

var SponsorHour = require("./../../../../models/SponsorHour");
var Agenda = require("./../../../../models/Agenda");
const { Validator } = require("node-input-validator");
var _ = require('lodash');
var moment = require("moment");
var mongoose = require("mongoose");
const timestamp = require("time-stamp");
created_date = timestamp.utc("YYYY-MM-DD HH:mm:ss");

const getRewardsCategory = async (req, res) => {
  console.log("getRewardsCategory-------------controller");
  try {
    const rewardsCategoryData = await RewardsCategory.find();
    res.json({
      status: 200,
      message: "Rewards category fetched",
      data: {
        rewardsCategoryData: rewardsCategoryData,
      },
    });
  } catch (error) {
    console.log("error.message------------>", error.message);
    res.json({
      status: 400,
      message: error.message,
      data: {},
    });
  }
};

const saveReward = async (userId, rewardCategory, rewardFor) => {
  console.log("--------saveReward invoked-----------");
  try {
    let rewardCategortData = await RewardsCategory.findOne({
      name: rewardCategory,
    });
    console.log("rewardCategortData------>", rewardCategortData);
    if (!rewardCategortData) {
      throw new Error("Invalid reward category");
    }

    let isRewardAlreadyClaimed = await Rewards.findOne({
      rewardFor: rewardFor,
      rewardCategory: rewardCategortData._id,
      userId:userId
    });
    console.log("isRewardAlreadyClaimed-------->", isRewardAlreadyClaimed);
    if (isRewardAlreadyClaimed) {
      throw new Error("Reward has already claimed");
    }

    let RewardData = new Rewards({
      userId: userId,
      rewardCategory: rewardCategortData._id,
      rewardPoints: rewardCategortData.rewardPoints,
      rewardFor: rewardFor,
      created_at: created_date,
      updated_at: created_date,
    });

    const savedData = await RewardData.save();
    console.log("savedData=======>", savedData);
    return {
      status: 200,
      message: "Reward claimed",
      data: {
        saveReward: savedData,
      },
    };
  } catch (error) {
    console.log("error.message------------>", error.message);
    return {
      status: 400,
      message: error.message,
      data: {},
    };
  }
};

const fetchPoints = async (req, res) => {
  console.log("--------fetchPoints invoked-----------");
  try {
    console.log("req.params=========>", req.params);

    // const data = await Rewards.aggregate([
    //   { $match: { userId: mongoose.Types.ObjectId(req.params.userId) } },
    //   { $group: { _id: "$rewardCategory", totalPoint: { $sum: "$rewardPoints" } } },
    // ]);
    const pointsPerCategort = await Rewards.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(req.params.userId) } },
      {
        $group: {
          _id: "$rewardCategory",
          pointsPerCategory: { $sum: "$rewardPoints" },
        },
      },
      {
        $lookup: {
          from: "rewardsCategory",
          localField: "_id",
          foreignField: "_id",
          as: "CategoryDetail",
        },
      },
    ]);
    console.log("data------------------->", pointsPerCategort);

    let totalPoint = await Rewards.aggregate([
      { $match: { userId: mongoose.Types.ObjectId(req.params.userId) } },
      {
        $group: {
          _id: "",
          totalPoint: { $sum: "$rewardPoints" },
        },
      },
    ]);

    console.log("totalPoint========================>", totalPoint);

    res.send({
      status: 200,
      message: "Points data fetched",
      data: {
        pointsData: {
          pointPerCategory:pointsPerCategort,
          totalPoint:totalPoint
        },
      },
    });
  } catch (error) {
    console.log("error.message====================>", error.message);
    res.send({
      status: 400,
      message: error.message,
      data: {},
    });
  }
};

const fetchLeaderBoard = async (req, res) => {
  console.log("--------fetchLeaderBoard invoked-----------");
  try {
    console.log("req.params=========>", req.params);
    
    const leaderBoardData = await Rewards.aggregate([
      {
        $group: {
          _id: "$userId",
          totalPoint: { $sum: "$rewardPoints" },
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "userDetail",
        },
      },
      { 
          $sort : { totalPoint : -1 } 
      }
    ]);
    console.log("data------------------->", leaderBoardData);

    const userIndex= _.findIndex(leaderBoardData, function(o) { return o._id == req.params.userId; });
    console.log("userIndex========================>", userIndex);

    res.send({
      status: 200,
      message: "Points data fetched",
      data: {
        leaderBoard: {
          leaderBoardData:leaderBoardData.slice(0, 6),
          userRank:userIndex+1
        },
      },
    });
  } catch (error) {
    console.log("error.message====================>", error.message);
    res.send({
      status: 400,
      message: error.message,
      data: {},
    });
  }
};

module.exports = {
  getRewardsCategory,
  saveReward,
  fetchPoints,
  fetchLeaderBoard
};
